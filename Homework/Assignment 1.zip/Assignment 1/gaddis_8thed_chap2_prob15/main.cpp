/*
 *File: main.cpp
 *Author: Norman Lee
 *Date: 6/25/15
 *Purpose: Draw a triangle
*/

//System Libraries
#include <iostream>
using namespace std;

//User libraries

//Global Constants

//Function Prototypes

//Execution starts here!

int main() {
	//Define Variables
	//Calculations
	//Output
	cout<<"  *\n"; 
	cout<<" ***\n";
	cout<<"*****\n";
	return 0;
}